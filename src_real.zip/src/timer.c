#include <system.h>

/* Saugo kiek taktų sistema veikia */
int timer_ticks = 0;

/* Apdoroja PIT. Šiuo konkrečiu atveju labai paprastai:
*  kiekvieną kartą įvykus taimerio pertraukimui „timer_ticks“ padidanamas
*  vienetu. Pagal nutylėjimą pertraukimai įvyksta 18,222 karto per sekundę. */
void timer_handler(struct regs *r) {
	/* Taktų skaitliukas padidinamas vienetu */
	timer_ticks++;

	/* Kas 18 taktų (apytiksliai kas sekundę) išvedame pranešimą */
	if (timer_ticks % 18 == 0) {
		//puts("Praejo viena sekunde\n\0");
	}
}

/* Sukonfigūruoja taimerį */
void timer_install() {
	/* Įdiegia „timer_handler“ į PU0 */
	irq_install_handler(0, timer_handler);
}

/* Ciklas suksis, kol bus pasiekta duoto laiko pabaiga */
void timer_wait(int ticks) {
	unsigned long eticks;

	eticks = timer_ticks + ticks;
	while (timer_ticks < eticks);
}
