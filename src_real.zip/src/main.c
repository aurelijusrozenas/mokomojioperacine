#include <system.h>

/* TODO */

/* Nukopijuoja count kiekį baitų iš src į dest */
unsigned char *memcpy(unsigned char *dest, const unsigned char *src, int count) {
	const char *sp = (const char*)src;
	char *dp = (char *) dest;
	for (; count != 0; count--)
		*dp++ = *sp++;
	return dest;
}

/* Nustato count kiekį baitų dest į val reikšmę */
unsigned char *memset(unsigned char *dest, unsigned char val, int count) {
	char *temp = (char *) dest;
	for (; count != 0; count--)
		*temp++ = val;
	return dest;
}

/* Identiška viršuj esančiai funkcijai, tik čia dirbama su 16 bitų reikšmėmims */
unsigned short *memsetw(unsigned short *dest, unsigned short val, int count) {
	unsigned short *temp = (unsigned short *) dest;
	for (; count != 0; count--)
		*temp++ = val;
	return dest;
}

/* Grąžina eilutės ilgį. Eilutės pabaigos simbolis '\0' */
int strlen(const char *str) {
	size_t retval;
	for (retval = 0; *str != '\0'; str++)
		retval++;
	return retval;
}

/* Funkcija nuskaitanti duomenis iš įvesties/išvesties prievado nurodytu adresu.
 * Joje pasitelkiame C kalbos galimybę iškviesti asemblerio funkcijas. */
unsigned char importb(unsigned short port) {
	unsigned char rv;
	__asm__ __volatile__ ("inb %1, %0" : "=a" (rv) : "dN" (port));
	return rv;
}

/* Įrašo duomenis į įvesties/išvesties prievadą nurodytu adresu */
void outportb(unsigned short port, unsigned char data) {
	__asm__ __volatile__ ("outb %1, %0" : : "dN" (port), "a" (data));
}

int main() {

	gdt_install();
	idt_install();
	isrs_install();
	irq_install();
	__asm__ __volatile__ ("sti");
	init_video();
	timer_install();
	keyboard_install();

	unsigned char *str = (unsigned char *) "Sveikas pasauli!\n\0";
	puts(str);

	//putch(1/0);

	for (;;)
		;
}

